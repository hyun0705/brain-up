// main.js - Entry point
import { renderMainIntro } from './ui/intro.js';
import { renderHome } from './ui/home.js';
import { $ } from './core/utils.js';
import { resetState } from './core/state.js';
import { getUserProfile } from './core/storage.js';
import { LS_KEYS, loadHistory } from './core/storage.js';
import { needsOnboarding, startOnboarding } from './ui/onboarding.js';

// 시작점 결정
function boot() {
  // 온보딩 필요한지 체크
  if (needsOnboarding()) {
    startOnboarding();
    return;
  }
  
  const profile = getUserProfile();
  const hasHistory = loadHistory(LS_KEYS.patternHistory).length > 0;
  
  // 프로필 있고 검사 기록 있으면 → 홈
  // 아니면 → 인트로
  if (profile && hasHistory) {
    renderHome();
  } else {
    renderMainIntro();
  }
}

boot();

// 로고 클릭 시 홈으로 이동
$("#logo").onclick = () => {
  const profile = getUserProfile();
  const hasHistory = loadHistory(LS_KEYS.patternHistory).length > 0;
  
  if (profile && hasHistory) {
    if (confirm('현재 진행 중인 작업을 중단하고 홈으로 돌아갈까요?')) {
      resetState();
      renderHome();
    }
  } else {
    if (confirm('현재 진행 중인 작업을 중단하고 처음으로 돌아갈까요?')) {
      resetState();
      renderMainIntro();
    }
  }
};
