// ui/intro.js
import { $ } from '../core/utils.js';
import { state, resetState } from '../core/state.js';
import { LS_KEYS, loadHistory, loadBaseline, getUserProfile, saveUserProfile, hasTestedThisWeek } from '../core/storage.js';
import { computeIndexFromBaseline } from '../core/scoring.js';
import { startPatternTest } from '../tests/pattern.js';
import { renderChartLegend, drawHistoryChart } from './result.js';
import { playClick } from '../core/sound.js';

// renderHome은 순환참조 방지를 위해 동적 import 사용
let renderHome = null;
async function getHome() {
  if (!renderHome) {
    const module = await import('./home.js');
    renderHome = module.renderHome;
  }
  return renderHome;
}

const app = $("#app");

export function renderMainIntro() {
  state.currentTest = null;
  state.phase = "intro";
  document.querySelector(".progress").textContent = "검사 -/4 · 인지기능";

  const profile = getUserProfile();
  const patternHist = loadHistory(LS_KEYS.patternHistory);
  const hasHistory = patternHist.length > 0;
  const lastRecord = hasHistory ? patternHist[patternHist.length - 1] : null;
  const lastDate = lastRecord ? new Date(lastRecord.ended_at).toLocaleDateString() : null;

  let profileSection = '';
  if (profile) {
    profileSection = `
      <div class="notice" style="margin-top:10px;">
        <b>내 정보</b>: ${profile.birthYear}년 ${profile.birthMonth}월생 (만 ${profile.age}세) · ${profile.gender === 'male' ? '남성' : '여성'}
        <button class="linkBtn" id="editProfile" style="margin-left:8px;">수정</button>
      </div>
    `;
  }

  let historySection = '';
  if (hasHistory) {
    historySection = `
      <div class="notice" style="margin-top:10px;">
        <b>이전 기록</b><br/>
        마지막 검사: ${lastDate} (총 ${patternHist.length}회)<br/>
        <button class="linkBtn" id="viewLastResult">이전 결과 보기 →</button>
      </div>
    `;
  }

  app.innerHTML = `
    <section class="card">
      <div class="pill">브레인 업</div>
      <h1 class="title">인지기능 검사</h1>
      <p class="desc">
        4가지 검사를 통해 <b>처리속도</b>, <b>주의력</b>, <b>기억력</b>, <b>공간지각</b>을 측정합니다.<br/>
        총 소요시간은 약 <b>6~8분</b>입니다.
      </p>
      <div class="notice">
        <b>검사 구성</b><br/>
        1. 패턴 비교 (처리속도)<br/>
        2. Go/No-Go (주의·억제)<br/>
        3. 숫자 기억 (작업기억)<br/>
        4. 위치 기억 (공간기억)
      </div>
      <div class="notice" style="margin-top:10px;">
        🔊 사운드를 켜주세요<br/>
        권장: <b>PC</b> 사용 · <b>전체화면</b> · 방해받지 않는 환경
      </div>
      ${profileSection}
      ${historySection}
      <div class="controls" style="grid-template-columns:1fr;margin-top:14px;">
        <button class="big" id="startAll">검사 시작하기</button>
      </div>
    </section>
  `;

  $("#startAll").onclick = () => {
    playClick();
    const profile = getUserProfile();
    if (!profile) {
      renderProfileInput();
    } else {
      startPatternTest();
    }
  };
  
  if (profile) {
    $("#editProfile").onclick = () => {
      playClick();
      renderProfileInput();
    };
  }
  
  if (hasHistory) {
    $("#viewLastResult").onclick = () => {
      playClick();
      renderPastResults();
    };
  }
}

export function renderProfileInput() {
  document.querySelector(".progress").textContent = "검사 -/4 · 정보 입력";
  
  const profile = getUserProfile();
  const currentYear = profile?.birthYear || '';
  const currentMonth = profile?.birthMonth || '';
  const currentGender = profile?.gender || '';

  // 연도 옵션 생성 (2007년까지 - 만 19세 이상)
  const thisYear = new Date().getFullYear(); // 2026년
  const maxBirthYear = thisYear - 19; // 2007년
  let yearOptions = '<option value="">연도</option>';
  for (let y = maxBirthYear; y >= 1920; y--) {
    yearOptions += `<option value="${y}" ${currentYear === y ? 'selected' : ''}>${y}년</option>`;
  }
  
  // 월 옵션
  let monthOptions = '<option value="">월</option>';
  for (let m = 1; m <= 12; m++) {
    monthOptions += `<option value="${m}" ${currentMonth === m ? 'selected' : ''}>${m}월</option>`;
  }

  app.innerHTML = `
    <section class="card">
      <div class="pill">시작 전 정보</div>
      <h1 class="title">기본 정보 입력</h1>
      <p class="desc">
        정확한 결과 분석을 위해 간단한 정보를 입력해주세요.<br/>
        입력하신 정보는 기기에만 저장되며 외부로 전송되지 않습니다.
      </p>
      
      <div class="formGroup">
        <label class="formLabel">생년월</label>
        <div class="selectGroup">
          <select id="yearSelect" class="formSelect">${yearOptions}</select>
          <select id="monthSelect" class="formSelect">${monthOptions}</select>
        </div>
      </div>
      
      <div class="formGroup">
        <label class="formLabel">성별</label>
        <div class="radioGroup">
          <label class="radioLabel">
            <input type="radio" name="gender" value="male" ${currentGender === 'male' ? 'checked' : ''}>
            <span class="radioText">남성</span>
          </label>
          <label class="radioLabel">
            <input type="radio" name="gender" value="female" ${currentGender === 'female' ? 'checked' : ''}>
            <span class="radioText">여성</span>
          </label>
        </div>
      </div>
      
      <div class="controls" style="margin-top:20px;">
        <button class="big" id="backBtn">뒤로</button>
        <button class="big" id="saveProfile">저장 후 시작</button>
      </div>
    </section>
  `;

  $("#backBtn").onclick = () => {
    playClick();
    renderMainIntro();
  };

  $("#saveProfile").onclick = () => {
    const birthYear = parseInt($("#yearSelect").value);
    const birthMonth = parseInt($("#monthSelect").value);
    const genderInput = document.querySelector('input[name="gender"]:checked');
    const gender = genderInput?.value;

    if (!birthYear) {
      alert('생년을 선택해주세요.');
      return;
    }
    if (!birthMonth) {
      alert('생월을 선택해주세요.');
      return;
    }
    if (!gender) {
      alert('성별을 선택해주세요.');
      return;
    }

    // 나이 계산
    const today = new Date();
    let age = today.getFullYear() - birthYear;
    if (today.getMonth() + 1 < birthMonth) {
      age--;
    }

    // 만 19세 미만 체크
    if (age < 19) {
      alert('본 검사는 만 19세 이상 성인을 대상으로 합니다.');
      return;
    }

    playClick();
    saveUserProfile({ birthYear, birthMonth, age, gender, updatedAt: Date.now() });
    startPatternTest();
  };
}

export function renderPastResults() {
  document.querySelector(".progress").textContent = "내 기록";

  const profile = getUserProfile();
  const patternHist = loadHistory(LS_KEYS.patternHistory);
  const gonogoHist = loadHistory(LS_KEYS.gonogoHistory);
  const digitspanHist = loadHistory(LS_KEYS.digitspanHistory);
  const spatialHist = loadHistory(LS_KEYS.spatialHistory);

  const lastPattern = patternHist[patternHist.length - 1];
  const lastGonogo = gonogoHist[gonogoHist.length - 1];
  const lastDigitspan = digitspanHist[digitspanHist.length - 1];
  const lastSpatial = spatialHist[spatialHist.length - 1];

  const getIndex = (hist, baselineKey) => {
    if (!hist) return { index: '-', label: '기록 없음' };
    const baseline = loadBaseline(baselineKey);
    return computeIndexFromBaseline(hist.summary.raw, baseline);
  };

  const pIdx = getIndex(lastPattern, LS_KEYS.patternBaseline);
  const gIdx = getIndex(lastGonogo, LS_KEYS.gonogoBaseline);
  const dIdx = lastDigitspan ? computeIndexFromBaseline(lastDigitspan.summary.totalSpan, loadBaseline(LS_KEYS.digitspanBaseline)) : { index: '-', label: '기록 없음' };
  const sIdx = getIndex(lastSpatial, LS_KEYS.spatialBaseline);

  const getBadgeClass = (label) => {
    if (label === "좋아지는 중") return "badgeGood";
    if (label === "변동 있음") return "badgeWarn";
    return "";
  };

  const lastDate = lastPattern ? new Date(lastPattern.ended_at).toLocaleDateString() : '-';
  
  let profileInfo = '';
  if (profile) {
    profileInfo = `<span style="color:var(--muted);font-size:14px;"> · 만 ${profile.age}세 ${profile.gender === 'male' ? '남성' : '여성'}</span>`;
  }

  app.innerHTML = `
    <section class="card">
      <h1 class="title">마지막 검사 결과</h1>
      <p class="desc">검사일: ${lastDate} (총 ${patternHist.length}회 기록)${profileInfo}</p>

      <div class="resultGrid">
        <div class="stat" style="padding:14px;">
          <div class="label">처리속도</div>
          <div class="value">${pIdx.index}<small>/100</small></div>
          <div style="font-size:14px;" class="${getBadgeClass(pIdx.label)}">${pIdx.label}</div>
          ${lastPattern ? `<div style="font-size:13px;color:var(--muted);margin-top:6px;">${lastPattern.summary.answered}문제 · ${Math.round(lastPattern.summary.accuracy * 100)}%</div>` : ''}
        </div>

        <div class="stat" style="padding:14px;">
          <div class="label">주의·억제</div>
          <div class="value">${gIdx.index}<small>/100</small></div>
          <div style="font-size:14px;" class="${getBadgeClass(gIdx.label)}">${gIdx.label}</div>
          ${lastGonogo ? `<div style="font-size:13px;color:var(--muted);margin-top:6px;">Go ${Math.round(lastGonogo.summary.goAcc * 100)}% · NoGo ${Math.round(lastGonogo.summary.nogoAcc * 100)}%</div>` : ''}
        </div>

        <div class="stat" style="padding:14px;">
          <div class="label">숫자 기억</div>
          <div class="value">${dIdx.index}<small>/100</small></div>
          <div style="font-size:14px;" class="${getBadgeClass(dIdx.label)}">${dIdx.label}</div>
          ${lastDigitspan ? `<div style="font-size:13px;color:var(--muted);margin-top:6px;">정순 ${lastDigitspan.summary.forwardSpan} · 역순 ${lastDigitspan.summary.backwardSpan}</div>` : ''}
        </div>

        <div class="stat" style="padding:14px;">
          <div class="label">위치 기억</div>
          <div class="value">${sIdx.index}<small>/100</small></div>
          <div style="font-size:14px;" class="${getBadgeClass(sIdx.label)}">${sIdx.label}</div>
          ${lastSpatial ? `<div style="font-size:13px;color:var(--muted);margin-top:6px;">${lastSpatial.summary.correctTrials}/6 · ${Math.round(lastSpatial.summary.avgAccuracy * 100)}%</div>` : ''}
        </div>
      </div>

      <div class="chartSection">
        <div class="label" style="margin-bottom:8px;">변화 추이 (최근 10회)</div>
        <canvas id="historyChart" style="width:100%;height:180px;"></canvas>
        ${renderChartLegend()}
      </div>

      <div class="controls" style="margin-top:14px;grid-template-columns:1fr;">
        <button class="big" id="backToIntro">홈으로</button>
      </div>
      
      ${hasTestedThisWeek() ? `
        <div class="notice" style="margin-top:12px;text-align:center;">
          <i class="fa-solid fa-circle-check" style="color:var(--good);"></i>
          이번 주 검사를 완료했어요. 다음 주에 다시 검사할 수 있어요.
        </div>
      ` : `
        <div class="controls" style="margin-top:12px;grid-template-columns:1fr;">
          <button class="big accent" id="startNew">새 검사 시작</button>
        </div>
      `}

    </section>
  `;

  setTimeout(() => drawHistoryChart('historyChart'), 50);

  $("#backToIntro").onclick = async () => {
    playClick();
    const home = await getHome();
    home();
  };
  
  if (!hasTestedThisWeek() && $("#startNew")) {
    $("#startNew").onclick = () => {
      playClick();
      resetState();
      startPatternTest();
    };
  }
}
