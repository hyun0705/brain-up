// ui/report.js
import { $ } from '../core/utils.js';
import { LS_KEYS, loadHistory, loadBaseline, getThisWeekTestResults, getCurrentWeekRange } from '../core/storage.js';
import { computeIndexFromBaseline } from '../core/scoring.js';
import { playClick } from '../core/sound.js';
import { renderHome } from './home.js';

const app = $("#app");

// 지난주 검사 결과 가져오기
function getLastWeekTestResults() {
  const { monday } = getCurrentWeekRange();
  
  // 지난주 범위 계산
  const lastSunday = new Date(monday);
  lastSunday.setDate(monday.getDate() - 1);
  lastSunday.setHours(23, 59, 59, 999);
  
  const lastMonday = new Date(lastSunday);
  lastMonday.setDate(lastSunday.getDate() - 6);
  lastMonday.setHours(0, 0, 0, 0);
  
  const patternHist = loadHistory(LS_KEYS.patternHistory);
  const gonogoHist = loadHistory(LS_KEYS.gonogoHistory);
  const digitspanHist = loadHistory(LS_KEYS.digitspanHistory);
  const spatialHist = loadHistory(LS_KEYS.spatialHistory);
  
  const filterLastWeek = (history) => {
    return history.filter(entry => {
      const entryDate = new Date(entry.ended_at);
      return entryDate >= lastMonday && entryDate <= lastSunday;
    });
  };
  
  return {
    pattern: filterLastWeek(patternHist),
    gonogo: filterLastWeek(gonogoHist),
    digitspan: filterLastWeek(digitspanHist),
    spatial: filterLastWeek(spatialHist)
  };
}

// 점수 비교 (이번주 vs 지난주)
function getComparison(thisWeek, lastWeek, key, baselineKey) {
  const thisResult = thisWeek[0];
  const lastResult = lastWeek[0];
  
  if (!thisResult) return { current: null, change: null, label: '기록 없음' };
  
  const baseline = loadBaseline(baselineKey);
  const currentIndex = computeIndexFromBaseline(thisResult.summary[key], baseline);
  
  if (!lastResult) {
    return { 
      current: currentIndex.index, 
      change: null, 
      label: currentIndex.label,
      isFirst: true
    };
  }
  
  const lastIndex = computeIndexFromBaseline(lastResult.summary[key], baseline);
  const change = currentIndex.index - lastIndex.index;
  
  return {
    current: currentIndex.index,
    previous: lastIndex.index,
    change: change,
    label: currentIndex.label
  };
}

// 변화 표시 텍스트
function getChangeText(change) {
  if (change === null) return '';
  if (change > 0) return `<span class="changeUp">+${change}</span>`;
  if (change < 0) return `<span class="changeDown">${change}</span>`;
  return `<span class="changeNeutral">±0</span>`;
}

// 종합 해석
function getOverallMessage(comparisons) {
  const changes = Object.values(comparisons)
    .filter(c => c.change !== null)
    .map(c => c.change);
  
  if (changes.length === 0) {
    return {
      icon: 'fa-solid fa-star',
      title: '첫 주간 검사를 완료했어요!',
      desc: '다음 주에도 검사하면 변화를 비교할 수 있어요.'
    };
  }
  
  const avg = changes.reduce((a, b) => a + b, 0) / changes.length;
  const improved = changes.filter(c => c > 0).length;
  const declined = changes.filter(c => c < 0).length;
  
  if (avg >= 3) {
    return {
      icon: 'fa-solid fa-arrow-trend-up',
      title: '지난주보다 좋아졌어요! 🎉',
      desc: '꾸준히 관리한 보람이 있네요. 이 컨디션을 유지해보세요.'
    };
  } else if (avg <= -3) {
    return {
      icon: 'fa-solid fa-arrow-trend-down',
      title: '지난주보다 조금 떨어졌어요',
      desc: '컨디션이나 환경 영향일 수 있어요. 걱정 마세요!'
    };
  } else {
    return {
      icon: 'fa-solid fa-minus',
      title: '지난주와 비슷해요',
      desc: '안정적으로 유지되고 있어요. 잘 하고 계세요!'
    };
  }
}

export function renderWeeklyReport() {
  document.querySelector(".progress").textContent = "주간 리포트";
  
  const thisWeek = getThisWeekTestResults();
  const lastWeek = getLastWeekTestResults();
  const { monday, sunday } = getCurrentWeekRange();
  
  // 각 영역별 비교
  const comparisons = {
    pattern: getComparison(thisWeek.pattern, lastWeek.pattern, 'raw', LS_KEYS.patternBaseline),
    gonogo: getComparison(thisWeek.gonogo, lastWeek.gonogo, 'raw', LS_KEYS.gonogoBaseline),
    digitspan: getComparison(thisWeek.digitspan, lastWeek.digitspan, 'totalSpan', LS_KEYS.digitspanBaseline),
    spatial: getComparison(thisWeek.spatial, lastWeek.spatial, 'raw', LS_KEYS.spatialBaseline)
  };
  
  const overall = getOverallMessage(comparisons);
  
  // 주간 범위 표시
  const formatDate = (date) => `${date.getMonth() + 1}/${date.getDate()}`;
  const weekRangeText = `${formatDate(monday)} ~ ${formatDate(sunday)}`;
  
  app.innerHTML = `
    <section class="card">
      <div class="reportHeader">
        <div class="reportWeek">${weekRangeText}</div>
        <h1 class="title">주간 리포트</h1>
      </div>
      
      <div class="reportOverall">
        <div class="reportOverallIcon"><i class="${overall.icon}"></i></div>
        <div class="reportOverallTitle">${overall.title}</div>
        <div class="reportOverallDesc">${overall.desc}</div>
      </div>
      
      <div class="reportGrid">
        <div class="reportItem">
          <div class="reportItemHeader">
            <span class="reportItemLabel">처리속도</span>
            ${getChangeText(comparisons.pattern.change)}
          </div>
          <div class="reportItemValue">${comparisons.pattern.current ?? '-'}<small>/100</small></div>
          <div class="reportItemStatus">${comparisons.pattern.label}</div>
        </div>
        
        <div class="reportItem">
          <div class="reportItemHeader">
            <span class="reportItemLabel">주의·억제</span>
            ${getChangeText(comparisons.gonogo.change)}
          </div>
          <div class="reportItemValue">${comparisons.gonogo.current ?? '-'}<small>/100</small></div>
          <div class="reportItemStatus">${comparisons.gonogo.label}</div>
        </div>
        
        <div class="reportItem">
          <div class="reportItemHeader">
            <span class="reportItemLabel">숫자 기억</span>
            ${getChangeText(comparisons.digitspan.change)}
          </div>
          <div class="reportItemValue">${comparisons.digitspan.current ?? '-'}<small>/100</small></div>
          <div class="reportItemStatus">${comparisons.digitspan.label}</div>
        </div>
        
        <div class="reportItem">
          <div class="reportItemHeader">
            <span class="reportItemLabel">위치 기억</span>
            ${getChangeText(comparisons.spatial.change)}
          </div>
          <div class="reportItemValue">${comparisons.spatial.current ?? '-'}<small>/100</small></div>
          <div class="reportItemStatus">${comparisons.spatial.label}</div>
        </div>
      </div>
      
      <div class="reportTip">
        <i class="fa-solid fa-lightbulb"></i>
        <span>매주 검사하면 변화 추이를 더 정확하게 볼 수 있어요</span>
      </div>
      
      <div class="controls" style="grid-template-columns:1fr;margin-top:20px;">
        <button class="big" id="backHome">홈으로</button>
      </div>
    </section>
  `;
  
  $("#backHome").onclick = () => { playClick(); renderHome(); };
}
